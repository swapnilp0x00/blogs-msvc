import React, { useState, useEffect } from 'react';
import axios from 'axios';


export default (props) => {
    // const [comments, setComments] = useState([]);

    // const fetchComments = async () => {
    //     const res = await axios.get('http://localhost:4001/posts/' + props.postId + '/comments');
    //     setComments(res.data);
    // }

    // useEffect(() => {
    //     fetchComments();
    // }, []);

    // PostList
    const comments = props.comments;
    const commentList = comments.map(comment => {
        let content;
        if (comment.status === 'rejected') {
            content = 'This comment is rejected';
        } else if (comment.status === 'pending') {
            content = 'This comment is under moderation';
        } else if (comment.status === 'approved') {
            content = comment.content;
        }

        return (<li key={comment.id}>{content}</li>)
    });
    console.log(comments);

    return (
        <ul>
            {commentList}
        </ul>);
}