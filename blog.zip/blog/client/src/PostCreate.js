import React, { useState } from "react";
import axios from 'axios';

export default () => {
    const [title, setTitle] = useState('');
    
    const inputChangeHandler = (event) => {
        console.log('Post content change');
        setTitle(event.target.value);
    }

    const submitHandler = async (event) => {
        console.log('submit post');
        event.preventDefault();
        await axios.post('http://localhost:4000/posts', {
            title
        });
        setTitle('');
    }

    return (
        <div>
            <form onSubmit={submitHandler}>
                <div className="form-group">
                    <label>Title</label>
                    <input value={title} onChange={inputChangeHandler} className="form-control"></input>
                </div>
                <button className="btn btn-primary">Submit</button>
            </form>
        </div>)
}