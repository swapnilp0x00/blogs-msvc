import React, { useState } from 'react';
import axios from 'axios';


export default (props) => {
    const [content, setContent] = useState('');

    const inputChangeHandler = (event) => {
        console.log('change comment');
        setContent(event.target.value);
    }

    const submitHandler = async (event) => {
        console.log('submit comment');
        event.preventDefault();
        await axios.post('http://localhost:4001/posts/' + props.postId + '/comments', {
            content
        });
        setContent('');
    }
    return (
        <div>
            <form onSubmit={submitHandler}>
                <div className="form-group">
                    <label>Add Comment</label>
                    <input value={content} placeholder="New Comment" className="form-control" onChange={inputChangeHandler}></input>
                </div>
                <button className="btn btn-primary">Submit</button>
            </form>
        </div>
    )
}