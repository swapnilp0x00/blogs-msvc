// Imports
const express = require('express');
const { randomBytes } = require('crypto');
const bodyParser = require('body-parser');
const cors = require('cors');
const axios = require('axios');

// -- Imports
const port = 4000;
const app = express();

// middleware
app.use(bodyParser.json());
app.use(cors());
// -- middlewares

// dummy data store
const posts = {};

// Index
app.get('/posts', (req, res, next) => {
    res.status(200).json(posts);
});

// Create
app.post('/posts', async (req, res, next) => {
    const id = randomBytes(4).toString('hex');
    const { title } = req.body;
    const post = {
        id, title
    }
    posts[id] = post

    // Inform Event Bus
    await axios.post('http://localhost:4005/events', {
        type: 'PostCreated',
        data: post
    });
    res.status(201).json(posts[id]);
});

// Do nothing on receiving events
app.post('/events', (req, res, next) => {
    const event = req.body;
    console.log('Recieved Event:', event.type);
    res.send({});
});

// App listen
app.listen(port, () => {
    console.log('Listening on', port);
});