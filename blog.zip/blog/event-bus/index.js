// Imports
const express = require('express');
const axios = require('axios');
const bodyParser = require('body-parser');
const cors = require('cors');

// -- Imports

const port = 4005
const app = express();
const events = [];

// middleware
app.use(bodyParser.json());
app.use(cors());
// -- middlewares

// Create
app.post('/events', (req, res, next) => {
    const event = req.body;
    events.push(event);
    console.log('Recieved', event.type);
    // Posts
    axios.post('http://localhost:4000/events', event);
    // Comments
    axios.post('http://localhost:4001/events', event);
    // Query Service
    axios.post('http://localhost:4002/events', event);
    // Moderation Service
    axios.post('http://localhost:4003/events', event);

    res.send({status: 'OK'});
});

app.get('/events', (req, res, next) => {
    res.send(events);
});

// App listen
app.listen(port, () => {
    console.log('Listening on', port);
});