// Imports
const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
const axios = require('axios');

// -- Imports

const port = 4002
const app = express();

// middleware
app.use(bodyParser.json());
app.use(cors());
// -- middlewares

const posts = {}

// Dedicated function to handle events
const handleEvents = (event) => {
    if (event.type === 'PostCreated') {
        const post = event.data;
        const {id, title} = post;
        posts[id] = {id, title, comments: []}
    } else if (event.type === 'CommentCreated') {
        const comment = event.data;
        const {postId, content, id, status} = comment;
        post = posts[postId];
        if (post){
            post.comments.push({id, content, status});
        }
    } else if (event.type === 'CommentUpdated') {
        const comment = event.data;
        const post = posts[comment.postId];
        let oldComment = post.comments.find(item => item.id === comment.id);
        oldComment.status = comment.status;
        oldComment.content = comment.content;
    }
}

// Index
app.get('/posts', (req, res, next) => {
    res.send(posts);
});


// Do nothing on receiving events
app.post('/events', (req, res, next) => {
    const event = req.body;
    console.log('Received Event', event.type);
    handleEvents(event);
    console.log(posts);
    res.send({});
});


// App listen
app.listen(port, async () => {
    console.log('Listening on', port);

    // Sync Code
    const res = await axios.get('http://localhost:4005/events');
    const events = res.data;

    for (let event of events) {
        handleEvents(event);
    }
});