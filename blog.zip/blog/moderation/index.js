// Imports
const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
const axios = require('axios');
// -- Imports

const port = 4003
const app = express();

// middleware
app.use(bodyParser.json());
app.use(cors());
// -- middlewares


const handleEvents = async (event) => {
    if (event.type === 'CommentCreated') {
        const comment = event.data;
        const status = comment.content.includes('orange') ? 'rejected' : 'approved';
        await axios.post('http://localhost:4005/events', {
            type: 'CommentModerated',
            data: {
                ...comment,
                status
            }
        });
    }
}

// Do nothing on receiving events
app.post('/events', async (req, res, next) => {
    const event = req.body;
    console.log('Received Event in Moderation', event.type);
    handleEvents(event);
    res.send({});
});


// App listen
app.listen(port, async () => {
    console.log('Listening on', port);

    // Sync code
    const res = await axios.get('http://localhost:4005/events');
    const events = res.data;
    for (let event of events) {
        handleEvents(event);
    }
});