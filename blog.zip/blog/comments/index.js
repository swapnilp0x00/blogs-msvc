// Imports
const express = require('express');
const { randomBytes } = require('crypto');
const bodyParser = require('body-parser');
const cors = require('cors');
const axios = require('axios');

// -- Imports

const port = 4001
const app = express();

// middleware
app.use(bodyParser.json());
app.use(cors());
// -- middlewares

// dummy data store
const commentsByPostId = {

};

// Index
app.get('/posts/:id/comments', (req, res, next) => {
    const postId = req.params.id;
    const comments = commentsByPostId[postId] || [];
    res.status(200).json(comments);
});

// Create
app.post('/posts/:id/comments', async (req, res, next) => {
    // create
    const commentId = randomBytes(4).toString('hex');
    const { content } = req.body;
    const comment = { id: commentId, content, status: 'pending' };
    // Get
    const postId = req.params.id;
    const comments = commentsByPostId[postId] || [];
    // update
    comments.push(comment);
    commentsByPostId[postId] = comments;

    await axios.post('http://localhost:4005/events', {
        type: 'CommentCreated',
        data: {
            postId,
            ...comment
        }
    });

    res.status(201).json(comments);
});

// Do nothing on receiving events
app.post('/events', async (req, res, next) => {
    const event = req.body;
    console.log('Recieved Event:', event.type);

    if (event.type === 'CommentModerated') {
        const newComment = event.data;

        const comments = commentsByPostId[newComment.postId] || [];
        const oldComment = comments.find(item => item.id === newComment.id);
        if (oldComment) {
            oldComment.status = newComment.status;
        }
        await axios.post('http://localhost:4005/events', {
            type: 'CommentUpdated',
            data: {
                postId: newComment.postId,
                ...oldComment
            }
        });
    }
    res.send({});
});


// App listen
app.listen(port, () => {
    console.log('Listening on', port);
});